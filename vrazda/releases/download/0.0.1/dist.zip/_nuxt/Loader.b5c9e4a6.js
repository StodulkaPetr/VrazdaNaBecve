import{K as f}from"./entry.53cdde5b.js";export{f as default};
