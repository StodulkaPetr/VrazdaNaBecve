import{_ as m}from"./Text.vue.c30cbbfd.js";import"./entry.53cdde5b.js";export{m as default};
