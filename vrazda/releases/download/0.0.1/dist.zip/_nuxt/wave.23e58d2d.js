import"./entry.53cdde5b.js";const i=""+globalThis.__publicAssetsURL("images/wave.svg");export{i as _};
