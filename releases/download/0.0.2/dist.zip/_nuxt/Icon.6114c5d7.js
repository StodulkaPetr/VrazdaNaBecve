import{_ as m}from"./Icon.vue.b8f9497f.js";import"./entry.85dad3cc.js";export{m as default};
