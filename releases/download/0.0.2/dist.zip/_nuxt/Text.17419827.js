import{_ as m}from"./Text.vue.e138f52d.js";import"./entry.85dad3cc.js";export{m as default};
