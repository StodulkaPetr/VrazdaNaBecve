import"./entry.8261ff0e.js";const i=""+globalThis.__publicAssetsURL("images/wave.svg");export{i as _};
