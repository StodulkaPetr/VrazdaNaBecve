import{_ as m}from"./Text.vue.4e298e5a.js";import"./entry.8261ff0e.js";export{m as default};
