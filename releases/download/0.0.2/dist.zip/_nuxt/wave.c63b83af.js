import"./entry.85dad3cc.js";const i=""+globalThis.__publicAssetsURL("images/wave.svg");export{i as _};
