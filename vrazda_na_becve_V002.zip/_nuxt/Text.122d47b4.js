import{_ as m}from"./Text.vue.33febb39.js";import"./entry.b6902ca4.js";export{m as default};
