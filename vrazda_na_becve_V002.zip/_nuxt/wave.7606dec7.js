import"./entry.b6902ca4.js";const i=""+globalThis.__publicAssetsURL("images/wave.svg");export{i as _};
