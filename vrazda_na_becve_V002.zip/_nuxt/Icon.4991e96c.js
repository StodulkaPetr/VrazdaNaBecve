import{_ as m}from"./Icon.vue.cb46bc64.js";import"./entry.b6902ca4.js";export{m as default};
